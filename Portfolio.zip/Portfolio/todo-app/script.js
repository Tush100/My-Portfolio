// DOM Elements
const taskInput = document.getElementById('task-input');
const addBtn = document.getElementById('add-btn');
const taskList = document.getElementById('task-list');
const clearAll = document.getElementById('clear-all');

// Initialize tasks array
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Render tasks from localStorage on page load
document.addEventListener('DOMContentLoaded', () => {
    renderTasks();
});

// Add new task
addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});

function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText !== '') {
        tasks.push({
            id: Date.now(),
            text: taskText,
            completed: false
        });
        saveTasks();
        renderTasks();
        taskInput.value = '';
    }
}

// Render all tasks
function renderTasks() {
    taskList.innerHTML = '';
    tasks.forEach(task => {
        const taskItem = document.createElement('li');
        taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
        taskItem.innerHTML = `
            <span>${task.text}</span>
            <div class="task-actions">
                <button class="complete-btn" data-id="${task.id}">
                    ${task.completed ? 'Undo' : 'Complete'}
                </button>
                <button class="delete-btn" data-id="${task.id}">Delete</button>
            </div>
        `;
        taskList.appendChild(taskItem);
    });

    // Add event listeners to new buttons
    document.querySelectorAll('.complete-btn').forEach(btn => {
        btn.addEventListener('click', toggleComplete);
    });
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', deleteTask);
    });
}

// Toggle task completion
function toggleComplete(e) {
    const taskId = parseInt(e.target.dataset.id);
    tasks = tasks.map(task => 
        task.id === taskId ? {...task, completed: !task.completed} : task
    );
    saveTasks();
    renderTasks();
}

// Delete task
function deleteTask(e) {
    const taskId = parseInt(e.target.dataset.id);
    tasks = tasks.filter(task => task.id !== taskId);
    saveTasks();
    renderTasks();
}

// Clear all tasks
clearAll.addEventListener('click', () => {
    tasks = [];
    saveTasks();
    renderTasks();
});

// Save tasks to localStorage
function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}